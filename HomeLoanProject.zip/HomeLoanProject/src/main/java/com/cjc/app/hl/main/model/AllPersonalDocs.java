package com.cjc.app.hl.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AllPersonalDocs {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int docId;
	private byte[] addressProof;
	private byte[] pancard;
	private byte[] adhaarCard;
	private byte[] photo;
	private byte[] signature;
	private byte[] thumb;
	private byte[] cancelledCheque;
	private byte[] propertyDoc;
	private byte[] cusSalarySlips;
	private byte[] cusProofOfBussiness;
	private byte[] cusForm16;
	private byte[] guaSalarySlips;
	
}
