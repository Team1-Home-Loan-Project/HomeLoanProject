package com.cjc.app.hl.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanDisbursement {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int disAgreementId;
	private int disloanNo;
	private String disAgreementDate;
	private String disAmountPayType;
	private double disActualLoanAmount;
	private double disTransferAmount;
	private String disBankName;
	private Double disAccountNumber;
	private String disIFSCCode;
	private String disAccountType;	
	private String disPaymentStatus;
	private String disAmountPaidDate;

}
