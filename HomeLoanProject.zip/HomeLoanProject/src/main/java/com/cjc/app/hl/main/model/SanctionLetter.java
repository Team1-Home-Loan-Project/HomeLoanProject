package com.cjc.app.hl.main.model;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class SanctionLetter {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sanId;
	private String sanctionDate;
	private String sanApplicantName;
	private String sanCustomerEmail;

	private long sanContactDetails;
	private String sanTypeOfLoan;
	private double sanLoanAmtSanctioned;
	private String interestType;
	@OneToOne(cascade = CascadeType.ALL)
	private  RateOfInterest rateOfInterest;
	private int sanLoanTenure;
	private double sanMonthlyEmiAmount;
	private String sanModeOfPayment;
	private String sanRemarks;
	private String sanTermsAndCondition;
	private String sanStatus;

}
