package com.cjc.app.hl.main.responseclass;

public class ResponseMessage extends RuntimeException{
	
	public ResponseMessage(String msg) {
		super(msg);
	}

}
