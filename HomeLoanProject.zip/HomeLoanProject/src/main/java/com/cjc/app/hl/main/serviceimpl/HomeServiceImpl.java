package com.cjc.app.hl.main.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.app.hl.main.model.AllPersonalDocs;
import com.cjc.app.hl.main.model.Cibil;
import com.cjc.app.hl.main.model.CustomerDetails;
import com.cjc.app.hl.main.model.EnquiryDetails;
import com.cjc.app.hl.main.model.GuarantorDetails;
import com.cjc.app.hl.main.model.Ledger;
import com.cjc.app.hl.main.model.LoanDisbursement;
import com.cjc.app.hl.main.model.SanctionLetter;
import com.cjc.app.hl.main.repository.AllPersonalRepository;
import com.cjc.app.hl.main.repository.CustomerDetailsRepository;
import com.cjc.app.hl.main.repository.CustomerVerificationRepository;
import com.cjc.app.hl.main.repository.EnquiryRepository;
import com.cjc.app.hl.main.repository.GuarantorRepository;
import com.cjc.app.hl.main.repository.LedgerRepository;
import com.cjc.app.hl.main.repository.LoanDisbursementRepository;
import com.cjc.app.hl.main.repository.LoanRepository;
import com.cjc.app.hl.main.repository.SanctionLetterReposiory;
import com.cjc.app.hl.main.repository.cibilRepository;
import com.cjc.app.hl.main.service.HomeService;

@Service
public class HomeServiceImpl implements HomeService {

	@Autowired
	EnquiryRepository enqRepo;
	
	@Autowired
	cibilRepository cibil;
	
	@Autowired
	AllPersonalRepository personal;
	
	@Autowired
	GuarantorRepository guaRepo;
	
	@Autowired
	CustomerDetailsRepository cr;
	
	@Autowired
	LedgerRepository lr;
	
	@Autowired
	CustomerVerificationRepository cv;
	
	@Autowired
	SanctionLetterReposiory sanr;
	
	@Autowired
	LoanDisbursementRepository disrepo;
	
	@Autowired
	LedgerRepository ledRepo;
	
	@Override
	public List<EnquiryDetails> getEnquiryAllData() {
		List<EnquiryDetails> list = enqRepo.findAll();
		return list;
	}

	@Override
	public Optional<EnquiryDetails> getSingleEnquiryAllData(int enqId) {
		Optional<EnquiryDetails> enq = enqRepo.findById(enqId);
		return enq;
	}
	@Override
	public EnquiryDetails addEnquiryData(EnquiryDetails enqDetails) {
		EnquiryDetails save = enqRepo.save(enqDetails);
		return save;
	}
	@Override
	public EnquiryDetails updateEnquiryData(EnquiryDetails enqDetails, int enId) {
		EnquiryDetails save = enqRepo.save(enqDetails);
		return save;
	}
	@Override
	public void deleteEnquiry(int enId) {
		
		enqRepo.deleteById(enId);
	}
	
	//----------------Cibil Override Methods-------------------------------------
	
	@Override
	public List<Cibil> getCibilAllData() {
		List<Cibil> list = cibil.findAll();
		return list;
	}
	@Override
	public Cibil addCibilData(Cibil cibilObj) {
		Cibil cib = cibil.save(cibilObj);
		return cib;
	}
	@Override
	public Cibil updateCibilData(Cibil cibilObj, int cibilId) {
		Cibil cib = cibil.save(cibilObj);
		return cib;
	}
	@Override
	public void deleteCibil(int cibilId) {
		cibil.deleteById(cibilId);
		
	}
	
	//----------------AllPersonalDocs Override Methods-------------------------------------
	
	@Override
	public List<AllPersonalDocs> getAllPersonalDocData() {
		List<AllPersonalDocs> list = personal.findAll();
		return list;
	}
	@Override
	public AllPersonalDocs addAllPersonalDocData(AllPersonalDocs personalObj) {
		AllPersonalDocs personalData = personal.save(personalObj);
		return personalData;
	}
	
	@Override
	public AllPersonalDocs getPersonalDocData(int docId) {
		AllPersonalDocs docObj = personal.findById(docId).get();
		return docObj;
	}
	
	//----------------Guarantor Override Methods-------------------------------------

	@Override
	public GuarantorDetails saveGuarantorData(GuarantorDetails gua) {
		GuarantorDetails save = guaRepo.save(gua);
		return save;
	}
	@Override
	public Iterable<GuarantorDetails> getAllGuarantorData() {
		Iterable<GuarantorDetails> list = guaRepo.findAll();
		return list;
	}
	@Override
	public Optional<GuarantorDetails> getGuarantorSingleData(int id) {
		Optional<GuarantorDetails> guadet= guaRepo.findById(id);
		return guadet;
	}
	@Override
	public void deleteGuarantorData(int id) {
		guaRepo.deleteById(id);
		
	}
	@Override
	public GuarantorDetails updateGuarantorData(int id, GuarantorDetails gd) {
		
		return guaRepo.save(gd);
	}
	
	//----------------CustomerDetails Override Methods-------------------------------------
	
	@Override
	public void insertCustomerDetailsData(CustomerDetails cd) {
		cr.save(cd);
	
		
	}
	@Override
	public List<CustomerDetails> getCustomerDetailsData() {
		
		return cr.findAll();

	}
	@Override
	public void deleteCustomerDetailsData(int id) {
		cr.deleteById(id);
		
	}
	@Override
	public CustomerDetails updateCustomerDetailsData(CustomerDetails cd) {
		CustomerDetails cusObj = cr.save(cd);
		return cusObj;
		
	}

	@Override
	public CustomerDetails getSingleCustomerData(int id) {
		CustomerDetails cusObj = cr.findById(id).get();
		return cusObj;
	}

	  //--------------------Sanction Override methods----------
	@Override
	public SanctionLetter insertSanctionData(SanctionLetter scn) {
		return sanr.save(scn);
		
	}

	@Override
	public List<SanctionLetter> getAllSanctiondata() {
		return sanr.findAll();
	
	}

	@Override
	public void deleteSanctionData(int sanId) {
		sanr.deleteById(sanId);
		
	}

	@Override
	public SanctionLetter getSingleSanction(int id) {
		SanctionLetter sl=sanr.findById(id).get();
		return sl;
		
	}
	
	//----------------------LoanDisburse Override

	@Override
	public LoanDisbursement insertLoanDisbursedData(LoanDisbursement d) {
		
		return	disrepo.save(d);
		
	}

	@Override
	public List<LoanDisbursement> getAllLoanDisburseddata() {
		List<LoanDisbursement> findAll = disrepo.findAll();
		return findAll;
	}

	@Override
	public void deleteLoanDisbursedData(int disAgreementId) {
		// TODO Auto-generated method stub
		disrepo.deleteById(disAgreementId);
	}

	@Override
	public LoanDisbursement getLoanDisburseDatabyId(int disAgreementId) {
		LoanDisbursement loanDisbursement = disrepo.findById(disAgreementId).get();
		return loanDisbursement;
	}

	//-------------------------Ledger Override methods
	@Override
	public void addLedger(Ledger l) {
		ledRepo.save(l);
		
	}

	@Override
	public List<Ledger> getAllLedger() {
		List<Ledger> findAll = ledRepo.findAll();
		return findAll;
	}

	@Override
	public Ledger getSingleLedger(int id) {
		Ledger ledger = ledRepo.findById(id).get();
		return ledger;
	}

	
	


}
