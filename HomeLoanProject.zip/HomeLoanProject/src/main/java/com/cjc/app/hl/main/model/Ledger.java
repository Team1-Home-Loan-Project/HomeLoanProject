package com.cjc.app.hl.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Ledger {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ledgerId;
	private String ledgerCreatedDate;
	private double ledTotalLoanAmount;
	private double ledPayableAmountWithInterest;
	private int ledTenure;
	private double ledMonlyEMI;
	private double ledAmountPaidtillDate;
	private double ledRemainingAmount;
	private String ledNextEmiDatestart;
	private String ledNextEmiDateEnd;
	private int ledDefaulterCount;
	//@OneToMany(cascade = CascadeType.ALL)
	//private defaulterList ledDefaulterList;
	private String ledPreviousEmitStatus;
	private String ledCurrentMonthEmiStatus;
	@OneToOne(cascade = CascadeType.ALL)
	private RateOfInterest ledRateOfInterest;
	private String ledTypeOfInterest;
	private String ledLoanEndDate;
	private String ledLoanStatus;
	//private String preclosure;
	
}
