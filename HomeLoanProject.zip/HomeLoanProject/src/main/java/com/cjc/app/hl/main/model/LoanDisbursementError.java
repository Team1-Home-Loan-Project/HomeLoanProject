package com.cjc.app.hl.main.model;

public class LoanDisbursementError {
	private int errorcode;
	private String loandisbursementmessage;
	public LoanDisbursementError(int errorcode, String loandisbursementmessage) {
		super();
		this.errorcode = errorcode;
		this.loandisbursementmessage = loandisbursementmessage;
	}
	public LoanDisbursementError() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(int errorcode) {
		this.errorcode = errorcode;
	}
	public String getLoandisbursementmessage() {
		return loandisbursementmessage;
	}
	public void setLoandisbursementmessage(String loandisbursementmessage) {
		this.loandisbursementmessage = loandisbursementmessage;
	}
	

}
