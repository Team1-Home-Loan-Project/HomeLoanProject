package com.cjc.app.hl.main.service;

import java.util.List;
import java.util.Optional;

import com.cjc.app.hl.main.model.AllPersonalDocs;
import com.cjc.app.hl.main.model.Cibil;
import com.cjc.app.hl.main.model.CustomerDetails;
import com.cjc.app.hl.main.model.EnquiryDetails;
import com.cjc.app.hl.main.model.GuarantorDetails;
import com.cjc.app.hl.main.model.Ledger;
import com.cjc.app.hl.main.model.LoanDisbursement;
import com.cjc.app.hl.main.model.SanctionLetter;

public interface HomeService {

	List<EnquiryDetails> getEnquiryAllData();

	EnquiryDetails addEnquiryData(EnquiryDetails enqDetails);

	EnquiryDetails updateEnquiryData(EnquiryDetails enqDetails, int enId);

	void deleteEnquiry(int enId);

	List<Cibil> getCibilAllData();

	Cibil addCibilData(Cibil cibil);

	Cibil updateCibilData(Cibil cibil, int cibilId);

	void deleteCibil(int cibilId);

	List<AllPersonalDocs> getAllPersonalDocData();

	AllPersonalDocs addAllPersonalDocData(AllPersonalDocs personalObj);

	GuarantorDetails saveGuarantorData(GuarantorDetails gua);

	Iterable<GuarantorDetails> getAllGuarantorData();

	Optional<GuarantorDetails> getGuarantorSingleData(int id);

	void deleteGuarantorData(int id);

	GuarantorDetails updateGuarantorData(int id, GuarantorDetails gd);

	void insertCustomerDetailsData(CustomerDetails cd);

	List<CustomerDetails> getCustomerDetailsData();

	void deleteCustomerDetailsData(int id);

	CustomerDetails updateCustomerDetailsData(CustomerDetails cd);

	Optional<EnquiryDetails> getSingleEnquiryAllData(int enqId);

	CustomerDetails getSingleCustomerData(int id);

	SanctionLetter  insertSanctionData(SanctionLetter scn);

	List<SanctionLetter> getAllSanctiondata();

	void deleteSanctionData(int sanId);

	SanctionLetter getSingleSanction(int id);

	AllPersonalDocs getPersonalDocData(int docId);

	LoanDisbursement insertLoanDisbursedData(LoanDisbursement d);

	List<LoanDisbursement> getAllLoanDisburseddata();

	void deleteLoanDisbursedData(int disAgreementId);

	LoanDisbursement getLoanDisburseDatabyId(int disAgreementId);

	void addLedger(Ledger l);

	List<Ledger> getAllLedger();

	Ledger getSingleLedger(int id);

}
