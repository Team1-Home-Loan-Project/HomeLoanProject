package com.cjc.app.hl.main.model;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class EnquiryDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eqId;
	private String eqName;
	private String eqDob;
	private int eqAge;
	private String eqGender;
	private String eqEmail;
	private long eqMobile;
	private String eqPanNo;
	private String eqTypeOfEmp;
	private String eqPropertyLocation;
	private double eqMonthlyIncome;
	@OneToOne(cascade = CascadeType.ALL)
	private Cibil cibil;
}
