package com.cjc.app.hl.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cjc.app.hl.main.model.LoanDisbursement;

public interface LoanDisbursementRepository extends JpaRepository<LoanDisbursement,Integer>{

	

	LoanDisbursement findBydisAgreementId(int disAgreementId);

	
	

}
