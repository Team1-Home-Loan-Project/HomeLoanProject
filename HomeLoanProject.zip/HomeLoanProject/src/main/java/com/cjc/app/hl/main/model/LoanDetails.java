package com.cjc.app.hl.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Entity
@Data
public class LoanDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
   private int loanId;
   private int loanNo;
   @OneToOne(cascade=CascadeType.ALL)
   private EMIDetails loanEmiDetails;
   private double loanAmount;
//   @OneToOne(cascade=CascadeType.ALL)
//   private rateOfInterest loanRateOfInterest;
   private int loanTenure;
   private double loanTotalAmountTobePaid;
   private int loanProcessingFees;
   
}
