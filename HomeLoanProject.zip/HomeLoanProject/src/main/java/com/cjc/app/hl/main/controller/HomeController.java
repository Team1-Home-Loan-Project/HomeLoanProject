package com.cjc.app.hl.main.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.cjc.app.hl.main.model.AllPersonalDocs;
import com.cjc.app.hl.main.model.Cibil;
import com.cjc.app.hl.main.model.CustomerDetails;
import com.cjc.app.hl.main.model.EnquiryDetails;
import com.cjc.app.hl.main.model.GuarantorDetails;
import com.cjc.app.hl.main.model.Ledger;
import com.cjc.app.hl.main.model.LoanDisbursement;
import com.cjc.app.hl.main.model.SanctionLetter;
import com.cjc.app.hl.main.responseclass.ResponseMessage;
import com.cjc.app.hl.main.service.HomeService;

@CrossOrigin("*")
@RestController
public class HomeController {
	
	@Autowired
	HomeService hs;
	
	@Autowired
	public JavaMailSender javamailsender;
	
	//-------------------EmailSend-------------
	@GetMapping("/send/{sendTo}")
	public String send(@PathVariable("sendTo") String sendTo)
	{
		SimpleMailMessage m=new SimpleMailMessage();
		System.out.println("sendTo"+sendTo);
		m.setTo(sendTo);
		m.setSubject("trail SENDER");
		m.setText("Home Loan.....");
		
		javamailsender.send(m);
		return "send";
		
	}
	
	//--------------------EnquiryCrud--------------------------
	
	@GetMapping("/getAllEnquiryData")
	public List<EnquiryDetails> getEnquiryDetailsAllData(){
		List<EnquiryDetails> list = hs.getEnquiryAllData();
		return list;
	}
	
	@GetMapping("/getSingleEnquiryData/{enqId}")
	public Optional<EnquiryDetails> getSingleEnquiryDetailsAllData(@PathVariable int enqId){
		Optional<EnquiryDetails> enquiry = hs.getSingleEnquiryAllData(enqId);
		return enquiry;
	}
	
	@PostMapping("/addEnquiryData")
	public EnquiryDetails addEnquiryDetails(@RequestBody EnquiryDetails enqDetails) {
		System.out.println("Status"+enqDetails.getCibil().getCibilStatus());
		if(enqDetails.getCibil().getCibilStatus().isEmpty())
		{
			Cibil cibils = new Cibil();
			cibils.setCibilStatus("Pending");
			enqDetails.setCibil(cibils);
		}
		EnquiryDetails enq = hs.addEnquiryData(enqDetails);
		return enq;
	}
	
	@PutMapping("updateEnquiryData/{enId}")
	public EnquiryDetails updateEnquiryDetails(@RequestBody EnquiryDetails enqDetails,@PathVariable int enId) {
		EnquiryDetails enq = hs.updateEnquiryData(enqDetails,enId);
		return enq;
	}
	
	@DeleteMapping("/deleteEnquiryData/{enId}")
	public void deleteEnquiryDetails(@PathVariable int enId )
	{
		hs.deleteEnquiry(enId);
	}
	
	//--------------------CibilCrud--------------------------
	
		@GetMapping("getAllCibilData")
		public List<Cibil> getCibilAllData(){
			List<Cibil> list = hs.getCibilAllData();
			return list;
		}
		
		@PostMapping("addCibilData")
		public Cibil addCibil(@RequestBody Cibil cibil) {
			Cibil cib = hs.addCibilData(cibil);
			return cib;
		}
		
		@PutMapping("updateCibilData/{CibilId}")
		public Cibil updateCibil(@RequestBody Cibil cibil,@PathVariable int cibilId) {
			Cibil cib = hs.updateCibilData(cibil,cibilId);
			return cib;
		}
		
		@DeleteMapping("deleteCibilData/{cibilId}")
		public void deleteCibil(@PathVariable int cibilId )
		{
			hs.deleteCibil(cibilId);
		}
		
		//-------------------Generate Cibil Scores--------------------------
		@GetMapping("/cibildata")
		public int cibilDate()
		{
		   int min=550;
		   int max=900;
		   System.out.println("Random value for cibil score from "+min+" to "+max+" is :");
			int cibil=(int)Math.floor(Math.random()*(max-min+1)+min);
			System.out.println(cibil);
			return cibil;
		}
		
		//--------------------AllPersonalDocumentCrud--------------------------
		
			@GetMapping("getAllPersonalDocData")
			public List<AllPersonalDocs> getAllPersonalDocData(){
				List<AllPersonalDocs> list = hs.getAllPersonalDocData();
				return list;
			}
			
			@GetMapping("getPersonalDocData/{docId}")
			public AllPersonalDocs getAllPersonalDocData(@PathVariable int docId){
				AllPersonalDocs doc = hs.getPersonalDocData(docId);
				return doc;
			}
			
			@PostMapping(value="/addAllPersonalDocData",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
			public AllPersonalDocs addAllPersonalDoc(@RequestPart(required = true,  value = "addressProof") MultipartFile file1,
					@RequestPart(required = true,  value = "pancard") MultipartFile file2,
					@RequestPart(required = true,  value = "adhaarCard") MultipartFile file3,
					@RequestPart(required = true,  value = "photo") MultipartFile file4,
					@RequestPart(required = true,  value = "signature") MultipartFile file5,
					@RequestPart(required = true,  value = "thumb") MultipartFile file6,
					@RequestPart(required = true,  value = "cancelledCheque") MultipartFile file7,
					@RequestPart(required = true,  value = "propertyDoc") MultipartFile file8,
					@RequestPart(required = true,  value = "cusSalarySlips") MultipartFile file9,
					@RequestPart(required = true,  value = "cusProofOfBussiness") MultipartFile file10,
					@RequestPart(required = true,  value = "cusForm16") MultipartFile file11,
					@RequestPart(required = true,  value = "guaSalarySlips") MultipartFile file12
					) 
					throws IOException {
				AllPersonalDocs personal = new AllPersonalDocs();
				personal.setAddressProof(file1.getBytes());
				personal.setPancard(file2.getBytes());
				personal.setAdhaarCard(file3.getBytes());
				personal.setPhoto(file4.getBytes());
				personal.setSignature(file5.getBytes());
				personal.setThumb(file6.getBytes());
				personal.setCancelledCheque(file7.getBytes());
				personal.setPropertyDoc(file8.getBytes());
				personal.setCusSalarySlips(file9.getBytes());
				personal.setCusProofOfBussiness(file10.getBytes());
				personal.setCusForm16(file11.getBytes());
				personal.setGuaSalarySlips(file12.getBytes());
				
				AllPersonalDocs allperdoc = hs.addAllPersonalDocData(personal);
						
				return allperdoc;
			}
			
//			@PutMapping("updateCibilData/{CibilId}")
//			public Cibil updateCibil(@RequestBody Cibil cibil,@PathVariable int cibilId) {
//				Cibil cib = hs.updateCibilData(cibil,cibilId);
//				return cib;
//			}
//			
//			@DeleteMapping("deleteCibilData/{cibilId}")
//			public void deleteCibil(@PathVariable int cibilId )
//			{
//				hs.deleteCibil(cibilId);
//			}
			
			//------------------GuarantorDetails Crud----------------------------
			@PostMapping("/saveGuarantor")
			public ResponseEntity<ResponseMessage> posGuarantortData(@RequestBody GuarantorDetails gua)
			{
				GuarantorDetails g=hs.saveGuarantorData(gua);
				if(g!=null)
				{
					return new ResponseEntity<ResponseMessage>(new ResponseMessage("Guarantor Details Saved Successfully"),HttpStatus.OK);
				}
				else
				{
					return new ResponseEntity<ResponseMessage>(new ResponseMessage("Guarantor Details Not Saved"),HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
			
		@GetMapping("/getAllGuarantor")
			public ResponseEntity<Iterable<GuarantorDetails>> getData()
			{
				Iterable<GuarantorDetails> list=hs.getAllGuarantorData();
				return new ResponseEntity<Iterable<GuarantorDetails>>(list,HttpStatus.FOUND);
			}
			
			@GetMapping("/getGuarantor/{gid}")
			public ResponseEntity<Optional<GuarantorDetails>> getSingleData(@PathVariable("gid") int id)
			{
				Optional<GuarantorDetails> guarantor=hs.getGuarantorSingleData(id);
				if(guarantor!=null)
				{
					return new ResponseEntity<Optional<GuarantorDetails>>(guarantor,HttpStatus.FOUND);
				}
				else
				{
					return new ResponseEntity<Optional<GuarantorDetails>>(HttpStatus.NOT_FOUND);
				}
			}
			
			@DeleteMapping("/deleteGuarantor/{gid}")
			public ResponseEntity<String> deleteData(@PathVariable("gid") int id)
			{
				hs.deleteGuarantorData(id);
				return new ResponseEntity<String>("Guarantor Deleted",HttpStatus.NO_CONTENT);
			}

			@PutMapping("/updateGuarantor/{gid}")
			public ResponseEntity<String> updateGuarantor(@PathVariable("gid") int id, @RequestBody GuarantorDetails gd)
			{
				GuarantorDetails g=hs.updateGuarantorData(id, gd);
				if(g!=null)
				{
					return new ResponseEntity<String>("Guarantor Details Updated Successfully",HttpStatus.OK);
				}
				else
				{
					return new ResponseEntity<String>("Guarantor Details Not Updated",HttpStatus.NOT_ACCEPTABLE);	
		  }
	}
			
			//--------------------------CustomerDetailsCrud---------------------------------------
			@PostMapping("/postCustomerData")
			public ResponseEntity<ResponseMessage> postData(@RequestBody CustomerDetails cd)
			{
				hs.insertCustomerDetailsData(cd);
				return new ResponseEntity<ResponseMessage>(new ResponseMessage("Data saved successfully"),HttpStatus.CREATED);
			}
//			@GetMapping("/get")
//			public ResponseEntity<ResponseMessage>getAll()
//			{
//				List <CustomerDetails> ld=hs.getCustomerDetailsData();
//				return new ResponseEntity<ResponseMessage>(new ResponseMessage("Data fetched successfully"),HttpStatus.OK);
//				
//			}
			
			@GetMapping("/getAllCustomerData")
			public List<CustomerDetails> getAll()
			{
				List<CustomerDetails> list =hs.getCustomerDetailsData();
				
			     return list;
				
			}
			
			@GetMapping("/getCustomerDataById/{cusId}")
			public CustomerDetails getsingle(@PathVariable("cusId") int id)
			{
				
				 CustomerDetails cd=hs.getSingleCustomerData(id);
				
			     return cd;
				
			}
			@DeleteMapping("/deleteCustomerData/{cusId}")
			public ResponseEntity<ResponseMessage>delete(@PathVariable("cusId")int id)
			{
					hs.deleteCustomerDetailsData(id);
				return new ResponseEntity<ResponseMessage>(new ResponseMessage("Data deleted successfully"),HttpStatus.NO_CONTENT);
				
			}
			@PutMapping("/updateCustomerData/{cusId}")
			public CustomerDetails putData(@RequestBody CustomerDetails cd,@PathVariable("cusId")int id)
			{
				CustomerDetails cusObj = hs.updateCustomerDetailsData(cd);
				return cusObj;
			}

			//--------------------SanctionCrud-----------------------------------

			@PostMapping("/insertSanctiondData")
			public ResponseEntity<ResponseMessage> saveSanctiondata(@RequestBody SanctionLetter scn)
			{
				SanctionLetter sanObj= hs.insertSanctionData(scn);
				if(sanObj!=null)
				{
					return new ResponseEntity<ResponseMessage> (new ResponseMessage("Data inserted...!!!"),HttpStatus.CREATED);

				}
				return new ResponseEntity<ResponseMessage> (new ResponseMessage("Data not inserted...!!!"),HttpStatus.INTERNAL_SERVER_ERROR);
		
			}
			
			@GetMapping("/getAllSanctiondData")
			public List<SanctionLetter> displayAllSacnData()
			{
				List<SanctionLetter> list = hs.getAllSanctiondata();
				return list;	
			}
			
			@GetMapping("/getSingleLetter/{sanId}")
			public SanctionLetter getSingle(@PathVariable("sanId") int id)
			{
				SanctionLetter c=hs.getSingleSanction(id);
				return c;
			}
//			
			@DeleteMapping("/deleteSanctiondData/{sanId}")
			public ResponseEntity<ResponseMessage> deleteSancdata(@PathVariable("sanId") int sanId)
			{
				
				hs.deleteSanctionData(sanId);
				return new ResponseEntity<ResponseMessage> (new ResponseMessage("delete data...!!!"),HttpStatus.NO_CONTENT);
			}
//			
//			@PutMapping("/updateSanctiondData/{sanId}")
//			public ResponseEntity<ResponseMessage> updateSandata(@RequestBody SanctionLetter scn, @PathVariable("sanId") int sanId)
//			{
//				hs.updateSanctionData(scn);
//				return new ResponseEntity<ResponseMessage> (new ResponseMessage("update Data...!!!"),HttpStatus.OK);
//			}
//			
			//-----------------LoanDisburse CRUD---------------------------
			
			 @PostMapping("/insertLoanDisbursementData")
				public LoanDisbursement savedata(@RequestBody LoanDisbursement d)
				{
				 LoanDisbursement lDisObj = hs.insertLoanDisbursedData(d);
					return lDisObj;
				}
			 
			 @GetMapping("/getAllDisbursedData")
				public List<LoanDisbursement> displayAllData()
				{
					List<LoanDisbursement> list = hs.getAllLoanDisburseddata();
					return list;	
				}
			 @DeleteMapping("/deleteLoanDisbursementData/{disAgreementId}")
				public ResponseEntity<ResponseMessage> deletedata(@PathVariable("disAgreementId") int disAgreementId)
				{
					hs.deleteLoanDisbursedData(disAgreementId);
					return new ResponseEntity<ResponseMessage> (new ResponseMessage("delete data...!!!"),HttpStatus.NO_CONTENT);
				}
			 @GetMapping("/getloandisbursedata/{disAgreementId}")
				public LoanDisbursement getDataById(@PathVariable int disAgreementId) {
					LoanDisbursement ldst=hs.getLoanDisburseDatabyId(disAgreementId);
					System.out.println("2.5");
					return ldst;
				}
			 
			 //-------------------------------Ledger CRUD-------------------------------
			 @PostMapping("/addLedger")
				public ResponseEntity<ResponseMessage> addData(@RequestBody Ledger l)
				{
//				    double p = l.getLedTotalLoanAmount();
////				 double p=2000;
////				 int t=5;
////				float r=0.08f;
//				
//			    System.out.println(p+"p");
//				    int t = l.getLedTenure();
//				    System.out.println("t"+t);
//				    float r = l.getLedRateOfInterest().getFixedRate();
//				    System.out.println(r+"r");
//			    int n = 12;
//			    double amount = p*Math.pow(1+(r/n), n*t);
//				    l.setLedPayableAmountWithInterest(amount);
//				    System.out.println("amount"+l.getLedPayableAmountWithInterest());
//				    
				hs.addLedger(l);
					return new ResponseEntity<ResponseMessage>(new ResponseMessage("Data Saved Successfully"),HttpStatus.CREATED);
				}
			 @GetMapping("/getAllLedger")
				public List<Ledger> getLedger()
				{
					List<Ledger> dl=hs.getAllLedger();
					return dl;
				} 

			 @GetMapping("/getLedger/{ledgerId}")
				public Ledger getSingleLedgerData(@PathVariable("ledgerId") int id)
				{
					Ledger l1=hs.getSingleLedger(id);
					return l1;
				}
 
			
}
	
			

